Bugs and feature requests only please.

For help questions, check out the forum: https://groups.google.com/forum/#!forum/tonejs

If possible, please include a link which illustrates the issue.

https://jsfiddle.net/1f60jkq4/ (tone@latest)
https://jsfiddle.net/z9marxbt/ (tone@next)