import Effect from "Tone/effect/Effect";
import Basic from "helper/Basic";
describe("Effect", function(){
	Basic(Effect);
});

